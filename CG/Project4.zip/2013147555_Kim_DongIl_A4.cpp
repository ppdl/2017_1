#include <GL/glut.h>
#include <cstdio>
#include <cmath>
#include <cstdlib>
using namespace std;

GLfloat ambient[] = { 0.3, 0.3, 0.3, 0.8 };
GLfloat diffuse[] = { 0.8, 0.8, 0.8, 0.8 };
GLfloat specular[] = { 0.8, 0.8, 0.8, 1 };

GLfloat mat_ambient[] = { 0.1, 0.2, 0.6, 0.3 };
GLfloat mat_diffuse[] = { 0.1, 0.2, 0.6, 0.3 };
GLfloat mat_specular[] = { 0.05, 0.6, 0.2, 0.4 };
GLfloat shinny[] = { 8 };

GLfloat last[] = { 1, 0, 0, 0,
					0, 1, 0, 0,
					0, 0, 1, 0,
					0, 0, 0, 1 };
GLfloat quat[] = { 1, 0, 0, 0,
					0, 1, 0, 0,
					0, 0, 1, 0,
					0, 0, 0, 1 };
GLfloat next[] = { 1, 0, 0, 0,
					0, 1, 0, 0,
					0, 0, 1, 0,
					0, 0, 0, 1 };
float startV[3], curV[3];

float light_theta = 0.00;
int winW, winH;
bool isRotate = false;
bool isLigtTurn = true;

//vector �ΰ��� ������ ����
bool equals(float* a, float* b)
{
	return (a[0] == b[0] && a[1] == b[1] && a[2] == b[2]);
}
//unit vector�� ����
void unit(float* a)
{
	float l = sqrtf(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]);
	a[0] /= l;
	a[1] /= l;
	a[2] /= l;
}

void init()
{
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, specular);

	glShadeModel(GL_SMOOTH);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_NORMALIZE);
}

void reshape(int w, int h)
{
	winW = w;
	winH = h;

	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(90.0f, (float)w / (float)h, 1.0f, 35.0f);
	gluLookAt(0, 0, 16, 0, 0, 0, 0, 1, 0);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void display()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	GLfloat light_dir[] = { cosf(light_theta), 0.0, sinf(light_theta), 0 };
	glLightfv(GL_LIGHT0, GL_POSITION, light_dir);

	glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_FRONT, GL_SHININESS, shinny);
	glPushMatrix();
	glMultMatrixf(quat);
	glutSolidTeapot(8.3);
	glPopMatrix();

	glutSwapBuffers();
}

void keyboard(unsigned char key, int x, int y)
{
	if (key == 27) exit(0); //esc key
	else if (key == ' ')
	{
		isLigtTurn = !isLigtTurn;
	}
	glutPostRedisplay();
}

void mouse(GLint button, GLint state, GLint tx, GLint ty)
{
	float x = (float)tx * 300.0 / (float)winW - 150.0;
	float y = 150.0 - (float)ty * 300.0 / (float)winH;

	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		if (sqrtf(x*x + y*y) <= 100.0)
		{
			for (int i = 0; i < 16; i++)
				last[i] = quat[i];
			startV[0] = x / 100.0;
			startV[1] = y / 100.0;
			startV[2] = sqrtf(10000.0 - (x*x + y*y)) / 100.0;
			unit(startV);
			isRotate = true;
		}
	}
	if(button == GLUT_LEFT_BUTTON && state == GLUT_UP)
		isRotate = false;
}

void motion(int tx, int ty)
{
	if (!isRotate) return;
	float x = (float)tx * 300.0 / (float)winW - 150.0;
	float y = 150.0 - (float)ty * 300.0 / (float)winH;

	if (sqrtf(x*x + y*y) <= 100.0)
	{
		curV[0] = x / 100.0;
		curV[1] = y / 100.0;
		curV[2] = sqrtf(10000.0 - (x*x + y*y)) / 100.0;
		unit(curV);
	}
	else
	{
		curV[0] = x;
		curV[1] = y;
		curV[2] = 0;
		unit(curV);
	}
	if (equals(startV, curV))	return;

	float norm[3];
	//Carculate Normal Vecor
	norm[0] = startV[1] * curV[2] - startV[2] * curV[1];
	norm[1] = startV[2] * curV[0] - startV[0] * curV[2];
	norm[2] = startV[0] * curV[1] - startV[1] * curV[0];
	unit(norm);
	//carculate angle
	float cos2 = (startV[0] * curV[0] + startV[1] * curV[1] + startV[2] * curV[2]);
	float q0, q1, q2, q3;
	if (cos2 > 1.0f - 0.000001f) return;	// cos���� 1�̻��̸� return
	//quaternion
	q0 = sqrt((1.0 + cos2)*0.5);
	q1 = norm[0] * sqrt((1.0 - cos2)*0.5);
	q2 = norm[1] * sqrt((1.0 - cos2)*0.5);
	q3 = norm[2] * sqrt((1.0 - cos2)*0.5);
	//quaternion rotation matrix
	next[0] = 1.0 - 2.0*q2*q2 - 2.0*q3*q3;
	next[1] = 2.0*q1*q2 + 2.0*q0*q3;
	next[2] = 2.0*q1*q3 - 2.0*q0*q2;
	next[4] = 2.0*q1*q2 - 2.0*q0*q3;
	next[5] = 1.0 - 2.0*q1*q1 - 2.0*q3*q3;
	next[6] = 2.0*q2*q3 + 2.0*q0*q1;
	next[8] = 2.0*q1*q3 + 2.0*q0*q2;
	next[9] = 2.0*q2*q3 - 2.0*q0*q1;
	next[10] = 1.0 - 2.0*q1*q1 - 2.0*q2*q2;
	//matrix �����ֱ�
	quat[0] = last[0] * next[0] + last[1] * next[4] + last[2] * next[8];
	quat[1] = last[0] * next[1] + last[1] * next[5] + last[2] * next[9];
	quat[2] = last[0] * next[2] + last[1] * next[6] + last[2] * next[10];
	quat[4] = last[4] * next[0] + last[5] * next[4] + last[6] * next[8];
	quat[5] = last[4] * next[1] + last[5] * next[5] + last[6] * next[9];
	quat[6] = last[4] * next[2] + last[5] * next[6] + last[6] * next[10];
	quat[8] = last[8] * next[0] + last[9] * next[4] + last[10] * next[8];
	quat[9] = last[8] * next[1] + last[9] * next[5] + last[10] * next[9];
	quat[10] = last[8] * next[2] + last[9] * next[6] + last[10] * next[10];
}

void idle()
{
	if(isLigtTurn)
		light_theta += 0.008;
	glutPostRedisplay();
}

int main()
{
	winW = 600; winH = 600;
	glutInitWindowSize(winW, winH);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
	glutCreateWindow("Rotation!");
	init();

	glutReshapeFunc(reshape);
	glutDisplayFunc(display);
	glutKeyboardFunc(keyboard);
	glutMouseFunc(mouse);
	glutMotionFunc(motion);
	glutIdleFunc(idle);
	glutMainLoop();
}